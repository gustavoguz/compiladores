// main.cpp
#include <cstdlib>
#include "../libs/planets.h"

int main(int argc, char *argv[]) {
	showMercury();
	showVenus();
	showEarth();
	system("sleep 1");
	return EXIT_SUCCESS;
}


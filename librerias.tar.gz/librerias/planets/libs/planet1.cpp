// planet1.cpp
#include <iostream>

void showMercury () {
   std::cout << "Primer planeta: Mercurio" << std::endl;
}


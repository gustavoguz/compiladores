// planet3.cpp
#include <iostream>

void showEarth () {
   std::cout << "Tercer planeta: Tierra" << std::endl;
}


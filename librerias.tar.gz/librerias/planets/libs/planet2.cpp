// planet2.cpp
#include <iostream>

void showVenus () {
   std::cout << "Segundo planeta: Venus" << std::endl;
}


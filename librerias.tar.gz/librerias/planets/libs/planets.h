// planets.h

#ifndef _PLANETS
  #define _PLANETS

  void showMercury();
  void showVenus();
  void showEarth();

#endif // _PLANETS

